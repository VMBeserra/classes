# Desafio Semana #1

```js
// Declarar uma variável chamada `myvar`, sem valor.
?

// Após declarada, atribua o valor 10 à variável `myvar`.
?

// Declare uma nova variável chamada `soma`, e adicione uma instrução somando os valores 15 e 8.
?

// Atribua à variável `soma` todo o valor dela, somando 1, usando o operador de soma abreviado.
?

// Atribua à variável `soma` todo o valor dela, multiplicando por 3, usando o operador de multiplicação abreviado.
?

// Qual é o valor da variável `soma` até aqui?
?

// Declare uma variável chamada `souninja`, atribuindo à ela o valor booleano que representa `verdadeiro`.
?

// Declare uma variável chamada `comida` que recebe um array com os valores 'arroz', 'feijão' e 'ovo'.
?

// Digite a instrução que imprime o valor de 'feijao', que está na variável `comida`.
?

// Digite o código que verifica se a variável `soma' é igual a variável `myvar` (testando também o tipo).
?

// Digite o código que verifica se a variável `myvar` é menor ou igual à variável `soma`.
?

// Crie uma função chamada `divisao` que receba como parâmetro dois números, e retorne o resultado da divisão entre eles.
?

// Invoque a função criada acima, passando os parâmetros 10 e 2.
?
```